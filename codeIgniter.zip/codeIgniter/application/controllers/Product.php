<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	function __construct()
    {
        // this is your constructor
        parent::__construct();
		$this->load->model(array('product_model'));
        $this->load->helper('form');
        $this->load->helper('url');
    }
	
	public function index()
	{
		
		
		$data['product_list']=$this->product_model->get_all('product');
		$this->load->view('product_list',$data);
	}
	public function list()
	{
		
		
		$prod=$this->product_model->get_all('product');
		if(!empty($prod)){
	 foreach ($prod as $row) {
		 $proimg="";
		 $arry_image=json_decode($row['product_image']);
		 if(!empty($arry_image)){
		 $proimg='<img src="'.str_replace("index.php/", "",base_url()).'uploads/'.$arry_image[0].'" style="width:20%" />';
		 }
      $data[] = array(
         "image"=>$proimg,
         "name"=>$row['product_name'],
         "price"=>$row['product_price'],
         "description"=>$row['product_description'],
		 "action"=>'<span class="glyphicon glyphicon-trash deloption"  data-oid="'.$row['id'].'">Delete  </span><span class="glyphicon glyphicon-trash editoption"  data-oid="'.$row['id'].'">EDIT  </span>',
      );
	  }
	   $response = array(
      "iTotalRecords" => count($prod),
      "iTotalDisplayRecords" =>count($prod),
      "aaData" => $data
   );
   }
   else{
   

   // Response
   $response = array(
      "iTotalRecords" => 0,
      "iTotalDisplayRecords" =>0,
      "aaData" => array()
   );
   }
   echo json_encode($response);
	}
	public function detailproduct()
	{
			
			$prod['details']=$this->product_model->get_row('product',array('id'=>$this->input->post('editid')));
			$prod['details']['product_image'] =str_replace('"','',trim($prod['details']['product_image'], '[]'));
			echo json_encode($prod);
	}

	public function add()
	{
		$this->load->helper('url');
		$im['file_name']="";
		if(isset($_POST) && ! empty($_POST)){
			
			 $data_image = [];
   
      $count = count($_FILES['files']['name']);
    
      for($i=0;$i<$count;$i++){
    
        if(!empty($_FILES['files']['name'][$i])){
          
          $_FILES['file']['name'] = $_FILES['files']['name'][$i];
          $_FILES['file']['type'] = $_FILES['files']['type'][$i];
          $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
          $_FILES['file']['error'] = $_FILES['files']['error'][$i];
          $_FILES['file']['size'] = $_FILES['files']['size'][$i];
  
          $config['upload_path'] = 'uploads/'; 
          $config['allowed_types'] = 'jpg|jpeg|png|gif';
          $config['max_size'] = '5000';
          $config['file_name'] = $_FILES['files']['name'][$i];
   
          $this->load->library('upload',$config); 
    
          if($this->upload->do_upload('file')){
            $uploadData = $this->upload->data();
            //$filename = $image_name;
			
   
            $data_image[] = $uploadData['file_name'];
          }
        }
   
      }
			$product_data = array(
                'product_name' => $this->input->post('product_name'),
				'product_price' => $this->input->post('product_price'),
				'product_description' => $this->input->post('product_description'),
				'product_image' => json_encode($data_image),
                
                
        );
        $ress=$this->product_model->insert("product",$product_data);
		$prod['editmessage']="add";
		echo json_encode($prod);
		
		exit;	
			}
		$this->load->view('add');
	}
	
	public function edit($id='')
	{
		$data = [];
		$data_image = [];
		$this->load->helper('url');
		$im['file_name']="";
		if(isset($_POST) && ! empty($_POST)){
			
			 $data_image = [];
   
      $count = count($_FILES['files']['name']);
    
      for($i=0;$i<$count;$i++){
    
        if(!empty($_FILES['files']['name'][$i])){
          $_FILES['file']['name'] = $_FILES['files']['name'][$i];
          $_FILES['file']['type'] = $_FILES['files']['type'][$i];
          $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
          $_FILES['file']['error'] = $_FILES['files']['error'][$i];
          $_FILES['file']['size'] = $_FILES['files']['size'][$i];
  
          $config['upload_path'] = 'uploads/'; 
          $config['allowed_types'] = 'jpg|jpeg|png|gif';
          $config['max_size'] = '5000';
          $config['file_name'] = $_FILES['files']['name'][$i];
   
          $this->load->library('upload',$config); 
    
          if($this->upload->do_upload('file')){
            $uploadData = $this->upload->data();
           
   
           $data_image[] = $uploadData['file_name'];
          }
        }
   
      }
			$upimage=$this->product_model->get_row('product',array('id'=>$this->input->post('product_id')));
			$fimage=json_encode($data_image);
			
			if($upimage['product_image']!=''){
				$fimage=json_encode(array_merge(json_decode($upimage['product_image']),$data_image));
			}
			
			$product_data = array(
                'product_name' => $this->input->post('product_name'),
				'product_price' => $this->input->post('product_price'),
				'product_description' => $this->input->post('product_description'),
				'product_image' => $fimage,
                
                
        );
        $ress=$this->product_model->update("product",$product_data,array('id'=>$this->input->post('product_id')));
		$prod['editmessage']="edit";
		$prod['details']=$this->product_model->get_row('product',array('id'=>$this->input->post('product_id')));
			$prod['details']['product_image'] =str_replace('"','',trim($prod['details']['product_image'], '[]'));
			echo json_encode($prod);
		//echo json_encode($response);
		
		exit;
			}
		$data['product_detail']=$this->product_model->get_row('product',array('id'=>$id));
		
		$this->load->view('edit',$data);
	}
	public function deleteimage()
	{
		$res=$this->product_model->get_row('product',array('id'=>$this->input->post('productid')));
		 $arry_image=json_decode($res['product_image']);
		 if(count($arry_image)==1){
			$final=''; 
		 }
		 else{
		if (false !== $key = array_search($this->input->post('imageid'), $arry_image)) {
  unset($arry_image[$key]);
}
			$final=json_encode(array_values($arry_image));
		}
		$this->product_model->update("product",array('product_image'=>$final),array('id'=>$this->input->post('productid')));
		
		echo 'success';
	}
	
	public function delete()
	{
		$this->product_model->delete('product',array('id'=>$this->input->post('deleteid')));
		echo 'success';
	}
}
