<?php
if (! defined('BASEPATH')) exit('No direct script access');

class Product_model extends CI_Model 
{
	function __construct()
	{
        parent::__construct();
		$this->load->database();
	}
	
	public function insert($tbl_name,$data)                

	{

		$this->db->insert($tbl_name,$data);

		$insert_id = $this->db->insert_id();
		return  $insert_id;

	}


	public function update($tbl_name,$data,$clause)        

	{

		$res=$this->db->update($tbl_name, $data,$clause); 
		return $res;

	}


	public function get_row($tbl_name,$data,$field='')      
	{
		if($field!=''){
			$this->db->select($field);
		}

		$qry=$this->db->get_where($tbl_name,$data);
		$result = $qry->row_array();
		$qry->free_result();
		return $result;

	}
	public function get_where_all($tbl_name,$data,$field='',$order='',$limit='')  
	{
		if($field!=''){
			$qry=$this->db->select($field);
		}
		
		if($order!=''){
			$qry=$this->db->order_by($order[0],$order[1]);
		}
		
		if($limit!=''){
			$qry=$this->db->limit($limit[0]);
		}
		
				
		$qry=$this->db->get_where($tbl_name,$data);
		
		
		$result = $qry->result_array();
		$qry->free_result();
		return $result;

	}

	public function get_all($table_name,$field='',$order='',$limit=''){
		if($field!=''){
			$qry=$this->db->select($field);
		}
		
		if($order!=''){

			$qry=$this->db->order_by($order[0],$order[1]);
		}
		
		if($limit!=''){
			$qry=$this->db->limit($limit[0],$limit[1]);
		}
		$qry = $this->db->get($table_name);
		$result = $qry->result_array();
		$qry->free_result();
		return $result;
	}
	
	

	public function delete($tbl_name,$clause){

		$res = $this->db->delete($tbl_name,$clause);
		return $res;
	}
	
	
	
	
	
	
}
?>