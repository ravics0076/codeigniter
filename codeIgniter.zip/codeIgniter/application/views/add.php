<h1>ADD PRODUCT</h1><br>
<form id="productadd" action="#" method="post" enctype="multipart/form-data">
<input type="text" id="product_name" name="product_name" placeholder="Enter Product Name" />
<input type="text" id="product_description" name="product_description" placeholder="Enter Product Description" />
<input type="text" id="product_price" name="product_price" placeholder="Enter Product Price" />
<input type='file' name='files[]' multiple="">
<input type="button" id="product_submit" name="product_submit" value="Submit" />
</form>
<br><br>
<a href="<?php echo base_url();?>product/">View Product</a>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">

$(document).ready(function(){
     $("#product_submit").on("click", function () {
		 var pname=$('#product_name').val();
		 var des=$('#product_description').val();
		 var price=$('#product_price').val();
          if(pname==''||des==''||price==''){
			  alert('Please fill all the field');
		  }
           else{		  
            var form = $('#productadd')[0];
                                    var data = new FormData(form);
              
                $.ajax({
                    type: 'post'
                    , url: '<?php echo base_url(); ?>product/add',
                     data:data,  
                     contentType: false,  
                     cache: false,  
                     processData:false,  
                     dataType: "json",
                     success: function (data) {
                        console.log(data);
                        
                        if (data != '') {
                            alert('Added Successfully');
                           
                            
                        }
                        else {
                           alert('Not Added');
                        }
                    }
                    
                });
	 }
            });
        });

</script>
