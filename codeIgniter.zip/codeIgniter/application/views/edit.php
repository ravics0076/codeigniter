<h1>EDIT PRODUCT</h1><br>
<form id="productadd" action="#" method="post" enctype="multipart/form-data">
<input type="hidden" id="product_id" name="product_id" value="<?php echo $product_detail['id'] ?>"  />
<input type="text" id="product_name" name="product_name" placeholder="Enter Product Name" value="<?php echo $product_detail['product_name'] ?>" />
<input type="text" id="product_description" name="product_description" placeholder="Enter Product Description" value="<?php echo $product_detail['product_description'] ?>" />
<input type="text" id="product_price" name="product_price" placeholder="Enter Product Price" value="<?php echo $product_detail['product_price'] ?>"  />
<input type='file' name='files[]' multiple="">
<input type="button" id="product_submit" name="product_submit" value="Submit" />
</form>
<?php if(isset($product_detail['product_image'])&&!empty($product_detail['product_image'])){
	$imagelist=json_decode($product_detail['product_image']);
	if(isset($imagelist)&&!empty($imagelist)){ foreach($imagelist as $imgelist){?>
	     <div class="deleteimage" data-imageid="<?php echo $imgelist; ?>">
		 <img src="http://localhost/codeigniter/uploads/<?php echo $imgelist; ?>" style="width:20%" />Delete</div>
	<?php } }
}

 ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
     $("#product_submit").on("click", function () {
           
            var form = $('#productadd')[0];
             var data = new FormData(form);
            
                $.ajax({
                    type: 'post'
                    , url: '<?php echo base_url(); ?>product/edit',
                     data:data,  
                     contentType: false,  
                     cache: false,  
                     processData:false,  
                     dataType: "json",
                     success: function (data) {
                        console.log(data);
                       
                        if (data != '') {
                            alert('Updated Successfully');
							location.reload(true);
                           
                            
                        }
                        else {
                           alert('Not Added');
                        }
                    }
                    
                });
            });
			
			$(".deleteimage").on("click", function () {
           
           
            
            var imageid =$(this).attr("data-imageid");
			var productid=$('#product_id').val();
			$(this).remove();
                $.ajax({
                    type: 'post'
                    , url: '<?php echo base_url(); ?>product/deleteimage'
                    , dataType: 'text'
                    , cache: false
                    , data:  {imageid: imageid,productid: productid}, 
                    success: function (data) {
                        console.log(data);
                        
                        if (data == 'success') {
                           
                          alert('Deleted Successfully'); 
                            
                        }
                        else {
                            
                        }
                    }
                    
                });
           
        });
        });

</script>
