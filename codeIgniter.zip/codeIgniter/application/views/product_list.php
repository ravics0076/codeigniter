<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.css"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.5/datatables.min.js"></script>
</head>
<body class="editor wide comments example">
 <table class="table datatable" id="example">
	<thead>
		<tr>
			<th>Image</th>
			<th>Name</th>
			<th>Price</th>
			<th>Description</th>
			<th>Action</th>
		</tr>
	</thead>
		
     </table>
	 <h1>PRODUCT</h1><br>
	 <p id="addnew" style="display:none">Add New</p>
<form id="productadd" action="#" method="post" enctype="multipart/form-data">
<input type="hidden" id="product_id" name="product_id"  />
<input type="text" id="product_name" name="product_name" placeholder="Enter Product Name" />
<input type="text" id="product_description" name="product_description" placeholder="Enter Product Description" />
<input type="text" id="product_price" name="product_price" placeholder="Enter Product Price" />
<input type='file' name='files[]' multiple="">
<input type="button" id="product_submit" name="product_submit" value="Submit" />
</form>
<div class="deleteimagee"></div>
<script type="text/javascript">
	$(document).ready(function() {
		$('#example').DataTable( {
			
		      	'processing': true,
		      	'serverSide': true,
		      	'serverMethod': 'post',
		      	'ajax': {
		          	'url':'<?php echo base_url(); ?>product/list'
		      	},
		      	'columns': [
		         	{ data: 'image' },
		         	{ data: 'name' },
		         	{ data: 'price' },
		         	{ data: 'description' },
					{ data: 'action' }
		      	]
		   });
		
	} );
</script>
 
<script>
$(document).ready(function(){
  $(document).on('click', '.deloption', function(){
	 
            var deleteid =$(this).attr("data-oid");
                $.ajax({
                    type: 'post'
                    , url: '<?php echo base_url(); ?>product/delete'
                    , dataType: 'text'
                    , cache: false
                    , data:  {deleteid: deleteid}, 
                    success: function (data) {
                        console.log(data);
                        
                        if (data == 'success') {
                           
                          alert('Deleted Successfully');
                          $('#example').DataTable().ajax.reload();						  
                            
                        }
                        else {
                            
                        }
                    }
                    
                });
           
        });
		$(document).on('click', '#addnew', function(){
			$('#addnew').hide();
			$('.deleteimagee').html('');
			$('#productadd')[0].reset();
			
		});
		$(document).on('click', '.editoption', function(){
			$('#addnew').show();
	        $('.deleteimagee').html('');
            var editid =$(this).attr("data-oid");
                $.ajax({
                    type: 'post'
                    , url: '<?php echo base_url(); ?>product/detailproduct'
                    , dataType: 'html'
                    , cache: false
                    , data:  {editid: editid}, 
                    success: function (data) {
                        console.log(data);
                        
                        
							var obj = jQuery.parseJSON(data);
							  $('#product_id').val(obj.details.id);
                              $('#product_name').val(obj.details.product_name);
							  $('#product_description').val(obj.details.product_description);
							  $('#product_price').val(obj.details.product_price);
							  let string = obj.details.product_image;
							  let arr = string.split(',');
							  console.log(arr);
							  $.each(arr, function(key, value) {
								if(value!=''){
								$('.deleteimagee').append('<div class="deleteimage"  data-imagename="'+value+'" data-imageid="'+obj.details.id+'"><img src="http://localhost/codeigniter/uploads/'+value+'" style="width:20%" />Delete</div>');
								}
								});
							  
                    }
                    
                });
           
        });
		
		$("#product_submit").on("click", function () {
		 var pname=$('#product_name').val();
		 var des=$('#product_description').val();
		 var price=$('#product_price').val();
          if(pname==''||des==''||price==''){
			  alert('Please fill all the field');
		  }
           else{		  
            var form = $('#productadd')[0];
			var suburl='<?php echo base_url(); ?>product/add';
			if($('#product_id').val()!=''){
				suburl='<?php echo base_url(); ?>product/edit';
			}
                                    var data = new FormData(form);
              
                $.ajax({
                    type: 'post'
                    , url: suburl,
                     data:data,  
                     contentType: false,  
                     cache: false,  
                     processData:false,  
                     dataType: "html",
                     success: function (data) {
                        
                        
                        if (data != '') {
							var obj = jQuery.parseJSON(data);
							console.log(obj.editmessage);
							if(obj.editmessage=='edit'){
							  $('#product_id').val(obj.details.id);
                              $('#product_name').val(obj.details.product_name);
							  $('#product_description').val(obj.details.product_description);
							  $('#product_price').val(obj.details.product_price);
							  let string = obj.details.product_image;
							  let arr = string.split(',');
							  console.log(arr);
							  $('.deleteimagee').html('');
							  $.each(arr, function(key, value) {
								if(value!=''){
								$('.deleteimagee').append('<div class="deleteimage"  data-imagename="'+value+'" data-imageid="'+obj.details.id+'"><img src="http://localhost/codeigniter/uploads/'+value+'" style="width:20%" />Delete</div>');
								}
								});
								alert('Updated Successfully');
							}
							else{
						alert('Added Successfully');
						}
							//$("#example").DataTable().destroy();
							
							$('#example').DataTable().ajax.reload();
							
                           
                            
                        }
                        else {
                           alert('Not Added');
                        }
                    }
                    
                });
	 }
            });
			
			
			
			
			$(document).on('click', '.deleteimage', function(){
           
           
            
            var imageid =$(this).attr("data-imagename");
			var productid=$(this).attr("data-imageid");
			//alert(imageid);
			$(this).remove();
                $.ajax({
                    type: 'post'
                    , url: '<?php echo base_url(); ?>product/deleteimage'
                    , dataType: 'text'
                    , cache: false
                    , data:  {imageid: imageid,productid: productid}, 
                    success: function (data) {
                        console.log(data);
                        
                        if (data == 'success') {
                           
                          alert('Deleted Successfully'); 
						  $('#example').DataTable().ajax.reload();
                            
                        }
                        else {
                            
                        }
                    }
                    
                });
           
        });
});
</script>

                 
 </body>
</html>